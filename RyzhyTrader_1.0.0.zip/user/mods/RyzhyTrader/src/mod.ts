import { DependencyContainer } from "tsyringe";

// SPT types
import { IPreSptLoadMod } from "@spt/models/external/IPreSptLoadMod";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { ILogger } from "@spt/models/spt/utils/ILogger";
import { PreSptModLoader } from "@spt/loaders/PreSptModLoader";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { ImageRouter } from "@spt/routers/ImageRouter";
import { ConfigServer } from "@spt/servers/ConfigServer";
import { ConfigTypes } from "@spt/models/enums/ConfigTypes";
import { ITraderConfig } from "@spt/models/spt/config/ITraderConfig";
import { IRagfairConfig } from "@spt/models/spt/config/IRagfairConfig";
import { JsonUtil } from "@spt/utils/JsonUtil";
import { Money } from "@spt/models/enums/Money";
import { Traders } from "@spt/models/enums/Traders";
import { HashUtil } from "@spt/utils/HashUtil";
import * as path from "path"
// New trader settings
import * as baseJson from "../db/base.json";

import { TraderHelper } from "./traderHelpers";
import { FluentAssortConstructor as FluentAssortCreator } from "./fluentTraderAssortCreator";
const fs = require('fs');
const modPath = path.normalize(path.join(__dirname, '..'));

class SampleTrader implements IPreSptLoadMod, IPostDBLoadMod
{
    private mod: string;
    private logger: ILogger;
    private traderHelper: TraderHelper;
    private fluentAssortCreator: FluentAssortCreator;

    constructor() {
        this.mod = "RyzhyTrader";
    }

    /**
     * Some work needs to be done prior to SPT code being loaded, registering the profile image + setting trader update time inside the trader config json
     * @param container Dependency container
     */
    public preSptLoad(container: DependencyContainer): void
    {
        // Get a logger
        this.logger = container.resolve<ILogger>("WinstonLogger");
        this.logger.debug(`[${this.mod}] preSpt Loading... `);

        // Get SPT code/data we need later
        const preSptModLoader: PreSptModLoader = container.resolve<PreSptModLoader>("PreSptModLoader");
        const imageRouter: ImageRouter = container.resolve<ImageRouter>("ImageRouter");
        const hashUtil: HashUtil = container.resolve<HashUtil>("HashUtil");
        const configServer = container.resolve<ConfigServer>("ConfigServer");
        const traderConfig: ITraderConfig = configServer.getConfig<ITraderConfig>(ConfigTypes.TRADER);
        const ragfairConfig = configServer.getConfig<IRagfairConfig>(ConfigTypes.RAGFAIR);

        this.traderHelper = new TraderHelper();
        this.fluentAssortCreator = new FluentAssortCreator(hashUtil, this.logger);
        this.traderHelper.registerProfileImage(baseJson, this.mod, preSptModLoader, imageRouter, "ryzhyTrader.jpg");
        this.traderHelper.setTraderUpdateTime(traderConfig, baseJson, 3600, 4000);

        Traders[baseJson._id] = baseJson._id;
        ragfairConfig.traders[baseJson._id] = true;
        this.logger.debug(`[${this.mod}] preSpt Loaded`);
    }

    /**
     * Majority of trader-related work occurs after the aki database has been loaded but prior to SPT code being run
     * @param container Dependency container
     */
    public postDBLoad(container: DependencyContainer): void
    {
        this.logger.debug(`[${this.mod}] postDb Loading... `);

        // Resolve SPT classes we'll use
        const databaseServer: DatabaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const configServer: ConfigServer = container.resolve<ConfigServer>("ConfigServer");
        const jsonUtil: JsonUtil = container.resolve<JsonUtil>("JsonUtil");
        const imageRouter = container.resolve< ImageRouter >("ImageRouter");
        const Wlogger = container.resolve<ILogger>("WinstonLogger");

        // Get a reference to the database tables
        const tables = databaseServer.getTables();

        // Add new trader to the trader dictionary in DatabaseServer - has no assorts (items) yet
        this.traderHelper.addTraderToDb(baseJson, tables, jsonUtil);

        //Water Bottle
        this.fluentAssortCreator.createSingleAssortItem("5448fee04bdc2dbc018b4567")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,10000)
        .addLoyaltyLevel(1)
        .export(tables.traders[baseJson._id]);

        //Emergency Water Ration
        this.fluentAssortCreator.createSingleAssortItem("60098b1705871270cd5352a1")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,15000)
        .addLoyaltyLevel(1)
        .export(tables.traders[baseJson._id]);

        
        //Moonshine
this.fluentAssortCreator.createSingleAssortItem("5d1b376e86f774252519444e")
.addStackCount(1)
.addMoneyCost(Money.ROUBLES,225000)
.addLoyaltyLevel(3)
.export(tables.traders[baseJson._id]);

//Vodka
this.fluentAssortCreator.createSingleAssortItem("614451b71e5874611e2c7ae5")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,25000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Jack Daniels
this.fluentAssortCreator.createSingleAssortItem("5d403f9186f7743cac3f229b")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,40000)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Aquamari
this.fluentAssortCreator.createSingleAssortItem("5c0fa877d174af02a012e1cf")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,35000)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Kvass
this.fluentAssortCreator.createSingleAssortItem("5e8f3423fd7471236e6e3b64")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,30000)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Pevko
this.fluentAssortCreator.createSingleAssortItem("62a09f32621468534a797acb")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,25000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Milk
this.fluentAssortCreator.createSingleAssortItem("575146b724597720a27126d5")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,28000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//RatCola
this.fluentAssortCreator.createSingleAssortItem("60b0f93284c20f0feb453da7")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,20000)
.addLoyaltyLevel(3)
.export(tables.traders[baseJson._id]);

//Pineapple
this.fluentAssortCreator.createSingleAssortItem("544fb62a4bdc2dfb738b4568")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,13500)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Grand Juice
this.fluentAssortCreator.createSingleAssortItem("57513f9324597720a7128161")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,11000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Vita Juice
this.fluentAssortCreator.createSingleAssortItem("57513fcc24597720a31c09a6")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,13000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Max Energy
this.fluentAssortCreator.createSingleAssortItem("5751435d24597720a27126d1")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,9000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//HotRod
this.fluentAssortCreator.createSingleAssortItem("5751496424597720a27126da")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,12500)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Apple Juice
this.fluentAssortCreator.createSingleAssortItem("57513f07245977207e26a311")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,9500)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//TarCola
this.fluentAssortCreator.createSingleAssortItem("57514643245977207f2c2d09")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,9000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Ice Green
this.fluentAssortCreator.createSingleAssortItem("575062b524597720a31c09a1")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,5000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Squash
this.fluentAssortCreator.createSingleAssortItem("57347d8724597744596b4e76")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,15000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Noodles
this.fluentAssortCreator.createSingleAssortItem("656df4fec921ad01000481a2")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,10000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Tarker
this.fluentAssortCreator.createSingleAssortItem("65815f0e647e3d7246384e14")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,13500)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Peas
this.fluentAssortCreator.createSingleAssortItem("57347d692459774491567cf1")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,8000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Sausage
this.fluentAssortCreator.createSingleAssortItem("635a758bfefc88a93f021b8a")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,20000)
.addLoyaltyLevel(3)
.export(tables.traders[baseJson._id]);

//Humpback
this.fluentAssortCreator.createSingleAssortItem("57347d5f245977448b40fa81")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,17000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Saury
this.fluentAssortCreator.createSingleAssortItem("5673de654bdc2d180f8b456d")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,9500)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Herring
this.fluentAssortCreator.createSingleAssortItem("57347d9c245977448b40fa85")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,15000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Mayo
this.fluentAssortCreator.createSingleAssortItem("5bc9b156d4351e00367fbce9")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,15000)
.addLoyaltyLevel(3)
.export(tables.traders[baseJson._id]);

//Cond. Milk
this.fluentAssortCreator.createSingleAssortItem("5734773724597737fd047c14")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,22000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Sugar
this.fluentAssortCreator.createSingleAssortItem("59e3577886f774176a362503")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,27000)
.addLoyaltyLevel(2)
.export(tables.traders[baseJson._id]);

//Oatflakes
this.fluentAssortCreator.createSingleAssortItem("57347d90245977448f7b7f65")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,9250)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Alyonka
this.fluentAssortCreator.createSingleAssortItem("57505f6224597709a92585a9")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,25000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Slickers
this.fluentAssortCreator.createSingleAssortItem("544fb6cc4bdc2d34748b456e")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,5500)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Croutons
this.fluentAssortCreator.createSingleAssortItem("57347d3d245977448f7b7f61")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,5000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Crackers
this.fluentAssortCreator.createSingleAssortItem("5448ff904bdc2d6f028b456e")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,7000)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

//Emelya
this.fluentAssortCreator.createSingleAssortItem("5751487e245977207e26a315")
.addUnlimitedStackCount()
.addMoneyCost(Money.ROUBLES,5500)
.addLoyaltyLevel(1)
.export(tables.traders[baseJson._id]);

        

        //Can of beef stew (Small)
        this.fluentAssortCreator.createSingleAssortItem("57347d7224597744596b4e72")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,15000)
        .addLoyaltyLevel(1)
        .export(tables.traders[baseJson._id]);

        //Can of beef stew (Large)
        this.fluentAssortCreator.createSingleAssortItem("57347da92459774491567cf5")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,17000)
        .addLoyaltyLevel(2)
        .export(tables.traders[baseJson._id]);

        //Sprats
        this.fluentAssortCreator.createSingleAssortItem("5bc9c29cd4351e003562b8a3")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,20000)
        .addLoyaltyLevel(3)
        .export(tables.traders[baseJson._id]);

        //Iskra
        this.fluentAssortCreator.createSingleAssortItem("590c5d4b86f774784e1b9c45")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,22000)
        .addLoyaltyLevel(1)
        .export(tables.traders[baseJson._id]);

        //MRE
        this.fluentAssortCreator.createSingleAssortItem("590c5f0d86f77413997acfab")
        .addUnlimitedStackCount()
        .addMoneyCost(Money.ROUBLES,26000)
        .addLoyaltyLevel(3)
        .export(tables.traders[baseJson._id]);

        //Golden Chain
        this.fluentAssortCreator.createSingleAssortItem("5734758f24597738025ee253")
        .addStackCount(3)
        .addMoneyCost(Money.ROUBLES,27000)
        .addLoyaltyLevel(2)
        .export(tables.traders[baseJson._id]);

        //Golden Smartphone
        this.fluentAssortCreator.createSingleAssortItem("5bc9b720d4351e450201234b")
        .addStackCount(1)
        .addMoneyCost(Money.ROUBLES,30000)
        .addLoyaltyLevel(3)
        .export(tables.traders[baseJson._id]);

        //Submariner
        this.fluentAssortCreator.createSingleAssortItem("59faf7ca86f7740dbe19f6c2")
        .addStackCount(2)
        .addMoneyCost(Money.ROUBLES,50000)
        .addLoyaltyLevel(3)
        .export(tables.traders[baseJson._id]);

        //Chainlet
        this.fluentAssortCreator.createSingleAssortItem("573474f924597738002c6174")
        .addStackCount(10)
        .addMoneyCost(Money.ROUBLES,10000)
        .addLoyaltyLevel(1)
        .export(tables.traders[baseJson._id]);

        this.traderHelper.addTraderToLocales(baseJson, tables, baseJson.name, "Ryzhy", baseJson.nickname, baseJson.location, "Finds a bunch of stuff he shouldn't have and has to hide from whoever is after him next.");

        //Quests Stuff
        this.importLocales(tables); // Import locales
        this.importQuests(tables,Wlogger); // Import the quest first
        this.importImages(imageRouter,Wlogger); //Import images as the last thing 
        
        this.logger.debug(`[${this.mod}] postDb Loaded`);
    }

    public getFiles(directory,extension,callback)
    {
        if (!fs.existsSync(directory)) return
        const dir = fs.readdirSync(directory, { withFileTypes: true })
        dir.forEach(item => {
            const itemPath = path.normalize(`${directory}/${item.name}`)
            if (item.isDirectory()) this.getFiles(itemPath, extension, callback)
            else if (extension.includes(path.extname(item.name))) callback(itemPath)
        });
    }

    public importQuests(database,logger)
    {
        this.getFiles(`${modPath}/db/quests/`, [".json"], function(filePath) {
            const item = require(filePath)
            if (Object.keys(item).length < 1) return 
            for (const quest in item) 
            {
                database.templates.quests[quest] = item[quest]
            }
        })
    }
    public importLocales(database)
    {
        const serverLocales = ['ch','cz','en','es','es-mx','fr','ge','hu','it','jp','pl','po','ru','sk','tu']
        const addedLocales = {}
        for (const locale of serverLocales) 
        {
            this.getFiles(`${modPath}/db/locales/${locale}`, [".json"], function(filePath) 
            {
                const localeFile = require(filePath)
                if (Object.keys(localeFile).length < 1) return
                for (const currentItem in localeFile) 
                {
                    database.locales.global[locale][currentItem] = localeFile[currentItem]
                    if (!Object.keys(addedLocales).includes(locale)) addedLocales[locale] = {}
                    addedLocales[locale][currentItem] = localeFile[currentItem]
                }
            })
        }
        for (const locale of serverLocales) {
            if (locale == "en") continue
            for (const englishItem in addedLocales["en"]) 
            {
                if (locale in addedLocales) 
                { 
                    if (englishItem in addedLocales[locale]) continue
                }
                if (database.locales.global[locale] != undefined) database.locales.global[locale][englishItem] = addedLocales["en"][englishItem]
            }
        }
    }

    public importImages(router,logger)
    {
        this.getFiles(`${modPath}/res/quests/`, [".png", ".jpg"], function(filePath) 
        {
            router.addRoute(`/files/quest/icon/${path.basename(filePath, path.extname(filePath))}`, filePath);
        })
    }
}

export const mod = new SampleTrader();
